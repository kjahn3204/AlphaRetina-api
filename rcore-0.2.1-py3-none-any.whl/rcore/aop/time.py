import time
from functools import wraps

from rcore.log import logger
from rcore.log.formatter import color_codes


def timeit(func):
    @wraps(func)
    def timeit_wrapper(*args, **kwargs):
        start_time = time.perf_counter()
        result = func(*args, **kwargs)
        end_time = time.perf_counter()
        total_time = end_time - start_time
        logger.info(f"{color_codes['yellow']}Function '{func.__name__}' Took {total_time:.4f} seconds{color_codes['reset']}")
        return result
    return timeit_wrapper


def atimeit(func):
    @wraps(func)
    async def timeit_wrapper(*args, **kwargs):
        start_time = time.perf_counter()
        result = await func(*args, **kwargs)
        end_time = time.perf_counter()
        total_time = end_time - start_time
        logger.info(f"{color_codes['yellow']}Function '{func.__name__}' Took {total_time:.4f} seconds{color_codes['reset']}")
        return result
    return timeit_wrapper
