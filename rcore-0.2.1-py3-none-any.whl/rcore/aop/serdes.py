from typing import Type

from typing_extensions import TypeAlias

from rcore.model.base import ModelBase, set_ignored_properties, set_model_dump_option

_TPropIgn: TypeAlias = 'set[int] | set[str] | dict[int, Any] | dict[str, Any] | None'


def json_ignore(props: _TPropIgn = None, unset: bool = False, default: bool = False, none: bool = False):
    """

    :param dict|set props: prop names to ignore properties not to be serialized.
                           props can be used like `exclude` prop for `model_dump()` in pydantic model
                           (ref. https://github.com/pydantic/pydantic/pull/648#issue-466035097)

    2024.02.24 dhpark: Decorator to ignore properties not to be serialized.
    2024.04.19 dhpark: added unset, default, and none for `model_dump()` in pydantic model

    example 1:
    >>> @json_ignore(props={'created'}, none=True)
    ... class Department(ModelBase):
    ...     id: str
    ...     name: str
    ...     location: str
    ...     created: datetime
    ...     changed: datetime | None = None
    ...
    >>> dept = Department(id='d1', name='department 01', location='Manhattan, NYC')
    >>> d = {'id': 'd1', 'name': 'department 01', 'location': 'Manhattan, NYC'}
    >>> assert dept.dict() == d
    True

    example 2:
    >>> from datetime import datetime
    >>> @json_ignore(props={'created'}, none=True)
    ... class Department(ModelBase):
    ...     id: str
    ...     name: str
    ...     location: str
    ...     created: datetime
    ...     changed: datetime | None = None
    >>> @json_ignore(props={
    ...     'id': ...,
    ...     'dept': {'id', 'created', 'changed'},
    ...     'changed': ...,
    ... }, none=True)
    ... class Person(ModelBase):
    ...     id: str
    ...     name: str
    ...     age: int
    ...     dept: Department
    ...     created: datetime
    ...     changed: datetime | None = None
    ...
    >>> dept = Department(id='d1', name='department 01', location='Manhattan, NYC', created=datetime(2024, 1, 1))
    >>> person = Person(id='p1', name='jake', age=20, dept=dept, created=datetime(2024, 1, 1))
    >>> assert person.json() == '{"name":"jake","age":20,"dept":{"name":"department 01","location":"Manhattan, NYC"},"created":"2024-01-01T00:00:00"}'
    True

    """

    def wrap(cls: Type[ModelBase]):
        option = {}
        if props is not None:
            set_ignored_properties(cls, props)

        if unset:
            option['exclude_unset'] = unset
        if default:
            option['exclude_default'] = default
        if none:
            option['exclude_none'] = none

        if len(option) > 0:
            set_model_dump_option(cls, option)

        return cls

    return wrap
