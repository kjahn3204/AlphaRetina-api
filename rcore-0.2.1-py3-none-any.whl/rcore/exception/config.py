from typing import Any, Dict

from rcore.exception.base import RapidException


class ConfigurationError(RapidException):
    def __init__(self, detail: str, extra: Any = None):
        super().__init__("Configuration을 수행하는 도중 문제가 발생했습니다.", detail, extra)


class ConfigNotFoundError(ConfigurationError):
    def __init__(self, config: Dict | None, extra: Any = None):
        super().__init__(f'config가 존재하지 않습니다. (config: {config})', extra)


class ConfigKeyNotExistError(ConfigurationError):
    def __init__(self, key: str, config: Dict, extra: Any = None):
        super().__init__(f'config에 해당 key가 없습니다. (key: {key}, config: {config})', extra)

