from typing import Any


class RapidException(Exception):
    msg: str | None
    detail: str | None
    extra: Any | None = None

    def __init__(self,
                 msg: str | None = None,
                 detail: str | None = None,
                 extra: Any | None = None):
        self.msg = msg
        self.detail = detail
        self.extra = extra

    @property
    def name(self) -> str:
        return self.__class__.__name__

    def __repr__(self) -> str:
        return f'<{self.name} msg="{self.msg}" detail="{self.detail}" extra="{self.extra}">'

    def __str__(self) -> str:
        return f'{self.msg} : {self.detail}'
