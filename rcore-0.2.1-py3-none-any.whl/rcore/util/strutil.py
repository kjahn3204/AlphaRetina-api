import re


def brief(s: str, length: int = 100) -> str:
    if len(s) <= length:
        return s
    else:
        return s[:length] + '...'


def deidentify(s: str):
    return re.sub(r'\d', '*', s)


def str_to_negative(s: str, tp: type):
    if s.endswith("-"):
        return -1 * tp(s[:-1])
    else:
        return tp(s)
