from typing import Dict, Any


def get_value_by_key(d: Dict[str, str], target_key: str) -> Any:
    for key, value in d.items():
        if isinstance(value, dict):
            yield from get_value_by_key(value, target_key)
        elif key == target_key:
            yield value


def update_value_by_key(d: Dict[str, str], target_key: str, value: str | None = None, value_mapper=lambda a: a) -> Any:
    for k, v in d.items():
        if isinstance(v, dict):
            update_value_by_key(v, target_key, value, value_mapper=value_mapper)
        elif k == target_key:
            d[k] = (value if value else value_mapper(v))
