def typename_to_type(typename: str) -> type:
    return type(typename)
