from threading import Thread


def is_thread_alive(thr_obj: Thread):
    if isinstance(thr_obj, Thread):
        if thr_obj.is_alive():
            return True
        else:
            return False
    else:
        return False
