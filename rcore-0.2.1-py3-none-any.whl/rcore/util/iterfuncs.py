from itertools import chain
from typing import List, Any, Iterable, Callable, TypeVar, Dict

import numpy as np

_T = TypeVar('_T')
_TK = TypeVar('_TK')
_TV = TypeVar('_TV')


def omit_none(l: List[Any]) -> List[Any]:
    return [i for i in l if i is not None]


def omit_keys(d: dict[str, Any], exclude_keys: List[str] | None) -> dict[str, Any]:
    if exclude_keys:
        return {k: v for k, v in d.items() if k not in exclude_keys}
    else:
        return {k: v for k, v in d.items()}


def first(condition: Callable[[_T], bool], __iterable: Iterable[_T]) -> _T:
    return next(filter(condition, __iterable), None)


def flatten(l: Iterable) -> List[Any]:
    return list(chain(*list(l)))


def combination(arr: List) -> List:
    # 2023.08.11 dhpark: way to get combinations of np array faster than 'itertools.combinations'
    n = np.array([a for a in arr if len(a) > 1])  # 한 글자인 경우는 세지 않음
    r = np.array(np.meshgrid(n, n)).T.reshape(-1, 2)
    c = r[
        (r[:, 0] != r[:, 1])  # 같은 단어의 경우는 세지 않음
        # & (1 < np.vectorize(len)(r[:, 0]))  # 한 글자인 경우는 세지 않음
        # & (1 < np.vectorize(len)(r[:, 1]))  # 한 글자인 경우는 세지 않음
    ]
    t = list(set([tuple(sorted(s)) for s in c]))
    return t


def groupby_mapper(src_list: List[_T],
                   to_list: bool = False,
                   key: Callable[[_T], Any] = lambda a: a,
                   key_mapper: Callable[[_T], _TK] | None = None,
                   value_mapper: Callable[[Any], _TV] = lambda a: a,
                   list_item_mapper: Callable[[_TK, _TV], Any] = lambda k, v: {'key': k, 'value': v},
                   ) -> Dict[str, Any] | List[Any] | None:
    if key_mapper is None:
        key_mapper = key
    keys = sorted(set([key(r) for r in src_list if key(r) is not None]))
    if to_list:
        result_list = []
        for k in keys:
            list_item_key = key_mapper(first(lambda r: key(r) == k, src_list))
            list_item_value = sorted([value_mapper(v)
                                      for v in src_list
                                      if key(v) == k and value_mapper(v) is not None])
            list_item = list_item_mapper(
                list_item_key,
                list_item_value if len(list_item_value) > 0 else None
            )
            result_list.append(list_item)

        if len(result_list) > 0:
            return result_list
        else:
            return []
    else:
        return {
            key_mapper(first(lambda r: key(r) == k, src_list)):
                [value_mapper(v)
                 for v in src_list
                 if key(v) == k and value_mapper(v) is not None]
            for k in keys
        }
