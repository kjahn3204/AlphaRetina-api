def safedelattr(obj: object, prop: str):
    if hasattr(obj, prop):
        delattr(obj, prop)
    else:
        pass
