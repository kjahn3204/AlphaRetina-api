import re
from typing import Tuple, List

import pandas as pd

replace_map = {
    '([(, ])nan([),])': r'\1NULL\2',
    'None': 'NULL',
    ':': r'\:',
    '\\\\xa0': '',
}


def _sqlize(s):
    s = str(s)
    for pattern, repl in replace_map.items():
        s = re.sub(pattern=pattern, repl=repl, string=s)
    return s


def df2sql(df: pd.DataFrame, table_name: str, upsert: bool):
    cols = df.columns
    rows = list(df.itertuples(index=False, name=None))

    query = rows2sql(rows, cols, table_name, upsert)
    return query


def rows2sql(rows: List[Tuple], cols: List[str], table_name: str, upsert: bool = False):
    if upsert:
        query = f"""
            INSERT INTO {table_name} (
                {','.join(cols)}
            ) VALUES {','.join(map(_sqlize, rows))}
            ON DUPLICATE KEY UPDATE
            {','.join([f'{c}=VALUES({c})' for c in cols])}
        """
    else:
        query = f"""
            INSERT IGNORE INTO {table_name} (
                {','.join(cols)}
            ) VALUES {','.join(map(_sqlize, rows))}
        """
    return query
