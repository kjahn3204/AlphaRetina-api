import platform
from datetime import datetime, timedelta, timezone


dtfmt = {
    'Y': '%Y',
    'M': '%Y-%m',
    'D': '%Y-%m-%d',
}

DEFAULT_TIMESTAMP_FMT = '%Y-%m-%d %H:%M:%S'
DEFAULT_DATE_FMT = '%Y%m%d'

KST = timezone(timedelta(hours=9))


def now():
    return datetime.now(KST)


def add_min(dt: datetime, min: int):
    return dt + timedelta(minutes=min)


def isYYYYMMDD(dtstr: str) -> bool:
    try:
        str_to_dt(dtstr, DEFAULT_DATE_FMT)
    except ValueError:
        return False
    return True


def validate(datestr) -> bool:
    valid = False
    try:
        datetime.strptime(datestr, dtfmt['Y'])
        valid = True
    except ValueError:
        pass

    try:
        datetime.strptime(datestr, dtfmt['M'])
        valid = True
    except ValueError:
        pass

    try:
        datetime.strptime(datestr, dtfmt['D'])
        valid = True
    except ValueError:
        pass

    return valid


def check_ymd(datestr) -> str:
    if validate(datestr) and datestr.count('-') == 2:
        return 'D'
    elif validate(datestr) and datestr.count('-') == 1:
        return 'M'
    elif validate(datestr) and datestr.count('-') == 0:
        return 'Y'
    else:
        raise ValueError(f'{datestr} is not a ymd format str')


def dt_to_str(dt: datetime, fmt: str = DEFAULT_TIMESTAMP_FMT) -> str:
    return dt.strftime(fmt)


def ts_to_dt(timestamp: int) -> datetime:
    if platform.system() == 'Windows':
        return datetime.fromtimestamp(timestamp/100).astimezone(KST)
    else:
        return datetime.fromtimestamp(timestamp).astimezone(KST)


def ts_to_str(timestamp: int) -> str:
    return dt_to_str(ts_to_dt(timestamp))


def str_to_dt(dtstr: str, fmt: str = DEFAULT_TIMESTAMP_FMT) -> datetime:
    return datetime.strptime(dtstr, fmt)


def str_to_ts(dtstr: str) -> int:
    return int(str_to_dt(dtstr).timestamp())


def today(fmt: str = DEFAULT_DATE_FMT) -> str:
    return dt_to_str(datetime.now(), fmt)


def yesterday(fmt: str = DEFAULT_DATE_FMT) -> str:
    return dt_to_str(datetime.now() - timedelta(days=1), fmt)


def add_days(date: str, days: int, fmt: str = DEFAULT_DATE_FMT) -> str:
    return dt_to_str(str_to_dt(date, fmt) + timedelta(days=days), fmt)


def diff_days(d1: str, d2: str, fmt: str = DEFAULT_DATE_FMT) -> int:
    return (str_to_dt(d1, fmt) - str_to_dt(d2, fmt)).days


def format_dt(dtstr: str, date: datetime = datetime.today()) -> str:
    return date.strftime(dtstr)


def has_date_fmt_str(dtstr: str) -> bool:
    fmt_str_list = DEFAULT_TIMESTAMP_FMT.replace('-', ' ') \
                                        .replace(':', ' ') \
                                        .split(' ')
    for fmt_str in fmt_str_list:
        if fmt_str in dtstr:
            return True
    return False

