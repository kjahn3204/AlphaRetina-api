from typing import Dict, Any
from uuid import uuid4

from rcore.constant import DEPLOY_MODE, POD_ID, PRJ_NAME, APP_NAME, POD_NUM, WORK_DIR
from rcore.util.date import today

config_replacements = {
    'work_dir': WORK_DIR,
    'deploy_mode': DEPLOY_MODE,
    'prj_name': PRJ_NAME,
    'app_name': APP_NAME,
    'pod_id': POD_ID,
    'pod_num': POD_NUM,
    'today': today(),
    'uuid': '',  # will be processed in `_replace()`
}


def _replace(src: str, key: str, value: str) -> str:
    if key == 'uuid':
        value = str(uuid4())
    return src.replace(f'{{{{{key}}}}}', value)


def resolve_mustache(src: Dict[str, Any] | str | None, replacements: Dict[str, str] | None = None) -> Dict | str | None:
    if replacements is not None:
        config_replacements.update(replacements)
    replacements = config_replacements

    if src is None:
        return None
    elif isinstance(src, str):
        target = str(src)  # copy
        for placeholder, replacement in replacements.items():
            target = _replace(target, placeholder, replacement)
    else:
        target = src.copy()
        for key, value in target.items():
            if isinstance(value, str):
                for placeholder, replacement in replacements.items():
                    value = _replace(value, placeholder, replacement)
            elif isinstance(value, dict):
                value = resolve_mustache(value, replacements)
            target[key] = value

    return target