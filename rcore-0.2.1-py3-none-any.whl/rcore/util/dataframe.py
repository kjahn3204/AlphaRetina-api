from typing import List

import pandas as pd


def merge_dfs(dfs: List[pd.DataFrame]):
    all_df = pd.DataFrame()
    for df in dfs:
        all_df = df if len(all_df) == 0 else pd.concat([all_df, df])
    return all_df


def rowcount(df: pd.DataFrame) -> int:
    return len(df.index)
