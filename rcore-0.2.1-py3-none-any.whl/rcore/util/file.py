import os
from typing import Tuple


def is_file(path: str | None) -> bool:
    return os.path.isfile(path)


def is_directory(path: str | None) -> bool:
    return os.path.isdir(path)


def split_path_and_name(src_path: str | None, check_exist: bool = True) -> Tuple[str | None, str | None]:
    if src_path is None:
        return None, None
    else:
        if check_exist:
            try:
                path, name = src_path.rsplit('/', 1)
            except (IndexError, AttributeError):
                return None, None

            if is_file(src_path):
                return path, name
            elif is_directory(path):
                return path, None
            else:
                return None, None
        else:
            path, name = src_path.rsplit('/', 1)
            return path, name


def get_filename_from_path(file_path: str, check_exist: bool = True) -> str | None:
    try:
        return split_path_and_name(file_path, check_exist)[1]
    except IndexError:
        return None


def get_dir_from_path(file_path: str) -> str | None:
    return file_path.rsplit('/', 1)[0]


def get_ext(filename: str) -> str:
    return filename.rsplit(".", 1)[1]


def change_ext(filename: str, ext: str) -> str:
    if filename.endswith(ext):
        return filename
    else:
        return f'{filename.rsplit(".", 1)[0]}.{ext}'
