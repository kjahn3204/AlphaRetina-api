import logging
from typing import Dict


default_colors = {
    'DEBUG': 'grey',
    'INFO': None,
    'WARNING': 'yellow',
    'ERROR': 'red',
    'CRITICAL': 'bold_red'
}


color_codes = {
    'red': "\x1b[31;20m",
    'green': "\x1b[32;20m",
    'yellow': "\x1b[33;20m",
    'blue': "\x1b[34;20m",
    'magenta': "\x1b[35;20m",
    'cyan': "\x1b[36;20m",
    'grey': "\x1b[90;20m",
    'default': "\x1b[39;20m",
    'bold_red': "\x1b[31;1m",
    'reset': "\x1b[0m",
}


class RapidLogColorFormatter(logging.Formatter):
    colors: Dict[str, str]

    def __init__(self, format: str | None = None, datefmt: str = None, style='%', colors: Dict | str = None, reset: bool = True):
        super(RapidLogColorFormatter, self).__init__(format, datefmt, style)
        if isinstance(colors, Dict):
            if len(colors.keys()) == 1 and 'all' in colors.keys():
                self.colors = {}
                color_name = colors['all']
                for log_level in default_colors.keys():
                    self.colors[log_level] = color_name
            else:
                self.colors = colors
        elif isinstance(colors, str):
            self.colors = {}
            for log_level in default_colors.keys():
                self.colors[log_level] = colors
        elif colors is None:
            self.colors = default_colors
        else:
            raise ValueError('colors must be a dict or a str')
        self.reset = reset

    def _get_color_code(self, color_name: str) -> str | None:
        return color_codes.get(color_name, None)

    def get_color_code_from_log_level(self, log_level_name: str) -> str | None:
        color_name = self.colors.get(log_level_name, None)
        color_code = self._get_color_code(color_name)
        return color_code

    @property
    def reset_code(self) -> str:
        if self.reset:
            return color_codes['reset']
        else:
            return ''

    def format(self, record: logging.LogRecord):
        original_msg = super().format(record)
        color_code = self.get_color_code_from_log_level(record.levelname)
        if color_code:
            colored_msg = f'{color_code}{original_msg}{self.reset_code}'
        else:
            colored_msg = original_msg
        return colored_msg
