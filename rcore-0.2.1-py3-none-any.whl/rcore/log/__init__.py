import logging
import os
from logging.config import dictConfig
from typing import Dict

from rcore.constant import GLOBAL_LOGGER_NAME
from rcore.log.filter import RapidLogFilter
from rcore.util.collection import get_value_by_key
from rcore.util.config import resolve_mustache
from rcore.util.file import get_dir_from_path


def setup_logging(cnf_log: Dict[str, str | Dict]):
    cnf_log = resolve_mustache(cnf_log)
    for filename in get_value_by_key(cnf_log, 'filename'):
        log_dir = get_dir_from_path(filename)
        os.makedirs(log_dir, exist_ok=True)

    dictConfig(cnf_log)


logger = logging.getLogger(GLOBAL_LOGGER_NAME)
