import logging

from rcore.constant import POD_ID, WORK_DIR, POD_NUM


class RapidLogFilter(logging.Filter):
    def filter(self, record: logging.LogRecord):
        module = record.pathname.replace(f'{WORK_DIR}/', '')\
                                 .replace('/', '.')\
                                 .replace('.py', '')
        # record.module = f'{module}:{record.lineno}({record.funcName})'
        record.module = f'{module}:{record.lineno}'
        record.pod_id = POD_ID
        record.pod_num = POD_NUM
        return True

