import glob
from typing import List

from rcore.constant import WORK_DIR
from rcore.util.iterfuncs import flatten


def _resolve_wildcard(pkg_str: str) -> List[str] | str:
    dir_sep = '/'
    try:
        import platform
        if platform.system() == 'Windows':
            dir_sep = '\\'
    except:
        pass

    if '*' in pkg_str:
        pattern = pkg_str.replace('.', dir_sep) + '.py'
    else:
        pattern = f'*{dir_sep}**{dir_sep}{pkg_str}.py'

    module_list = glob.glob(f'{WORK_DIR}{dir_sep}{pattern}', recursive=True)

    return [s.replace(f'{WORK_DIR}{dir_sep}', '')
            .replace('.py', '')
            .replace(dir_sep, '.')
            for s in module_list]


def autowire(container, config):
    packages_patterns: List[str] = config.get('packages', [])
    modules_patterns: List[str] = config.get('modules', [])
    exclude_patterns: List[str] = config.get('excludes', [])

    excluded_target = set(flatten(map(_resolve_wildcard, exclude_patterns)))
    target_packages = set(flatten(map(_resolve_wildcard, packages_patterns)))
    target_modules = set(flatten(map(_resolve_wildcard, modules_patterns)))

    packages = target_packages - excluded_target
    modules = target_modules - excluded_target

    container.wire(
        packages=packages,
        modules=modules,
    )
