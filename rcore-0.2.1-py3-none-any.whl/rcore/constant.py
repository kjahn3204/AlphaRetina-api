import os
import pathlib

RCORE_ROOT_DIR = str(pathlib.Path(__file__).parent.parent.resolve())
CORE_CONFIG_PATH = f'{RCORE_ROOT_DIR}/rcore/config/core.yaml'

WORK_DIR = os.environ.get('WORK_DIR')
assert WORK_DIR is not None

DEPLOY_MODE = os.environ.get('DEPLOY_MODE')
assert DEPLOY_MODE is not None

VERSION = os.environ.get('VERSION', '0.0.1-local')
PRJ_NAME = os.environ.get('PRJ_NAME', 'rcore')
APP_NAME = os.environ.get('APP_NAME', 'app')

GLOBAL_LOGGER_NAME = "rcore"

POD_ID = os.environ.get('POD_ID', 'LOCAL')
POD_NUM = 'LOCAL' if POD_ID == 'LOCAL' else POD_ID.rsplit('-', 1)[1]
