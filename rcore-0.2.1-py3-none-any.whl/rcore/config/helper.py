from typing import Dict

from dependency_injector.wiring import inject, Provide

from rcore.exception.config import ConfigKeyNotExistError
from rcore.util.config import resolve_mustache


@inject
def get_config(exp: str, config: Dict = Provide['config']) -> Dict | str | int | None:
    cnf = config.copy()
    exp = exp.strip()
    if exp.startswith('.'):
        exp = exp[1:]
    if exp.endswith('.'):
        exp = exp[:-1]
    keys = exp.split('.')

    try:
        for i, key in enumerate(keys):
            cnf = cnf[key]
    except KeyError as e:
        raise ConfigKeyNotExistError(str(e), cnf)

    return resolve_mustache(cnf)
