from typing import List, TypeVar, Generic, Dict, Any

from pydantic import BaseModel
from typing_extensions import TypeAlias

_TPropIgn: TypeAlias = 'set[int] | set[str] | dict[int, Any] | dict[str, Any] | None'


__ignored_fields__: Dict[str, Dict[str, Any]] = {}
__model_dump_option__: Dict[str, Dict[str, Any]] = {}


class ModelBase(BaseModel):
    __ignored_local_fields__ = {'__fields_set__': ..., 'model_extra': ..., 'model_fields_set': ...}

    @classmethod
    def get_properties(cls) -> Dict[str, Any]:
        props = {prop: ... for prop in dir(cls) if isinstance(getattr(cls, prop), property)}
        props.update({k: ... for k, v in cls.model_fields.items()})
        return props

    @classmethod
    def get_ignored_properties(cls) -> Dict[str, Any] | None:
        global_ignored = __ignored_fields__.get(cls.__name__)
        local_ignored = cls.__ignored_local_fields__

        if global_ignored is not None:
            ignore_props = global_ignored.copy()
            if isinstance(global_ignored, dict):
                ignore_props.update(local_ignored)
            elif isinstance(global_ignored, set):
                ignore_props.update({k: ... for k in local_ignored})
            return ignore_props
        else:
            return None

    @classmethod
    def get_serializable_props(cls) -> Dict[str, Any]:
        include = cls.get_properties()
        exclude = cls.get_ignored_properties()
        return {x: ... for x in include.keys() if x not in exclude.keys()}

    def _kwargs_dump_option(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        exclude = self.get_ignored_properties()
        if exclude:
            kwargs['exclude'] = exclude
        if self.__class__.__name__ in __model_dump_option__.keys():
            kwargs.update(__model_dump_option__[self.__class__.__name__])
        return kwargs

    def model_dump(self, *args, **kwargs) -> Dict[str, Any]:
        return super().model_dump(*args, **self._kwargs_dump_option(kwargs))

    def model_dump_json(self, *args, **kwargs) -> str:
        return super().model_dump_json(*args, **self._kwargs_dump_option(kwargs))

    def to_entity(self):
        raise NotImplementedError

    def __str__(self):
        return self.model_dump_json()


def set_ignored_properties(cls, props: _TPropIgn) -> None:
    global __ignored_fields__
    classname = cls.__name__
    __ignored_fields__[classname] = props


def set_model_dump_option(cls, option) -> None:
    global __model_dump_option__
    classname = cls.__name__
    __model_dump_option__[classname] = option


TModel = TypeVar("TModel", bound=ModelBase)


class PageModel(ModelBase, Generic[TModel]):
    page: int | None = None
    size: int | None = None
    count: int | None = None
    total: int | None = None
    result: List[TModel | Any]

